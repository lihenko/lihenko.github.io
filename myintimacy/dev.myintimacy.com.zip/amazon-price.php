<?php
/**
 * The template for displaying Amazon Price page
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package MyIntimacy
 */


$servername = "localhost";
$username = "myintimacycom";
$password = "myintimacycom";
$dbname = "myintimacy";

?>

<h1>Amazon Price</h1></div>

					<?php 

						use Amazon\ProductAdvertisingAPI\v1\ApiException;
						use Amazon\ProductAdvertisingAPI\v1\com\amazon\paapi5\v1\api\DefaultApi;
						use Amazon\ProductAdvertisingAPI\v1\com\amazon\paapi5\v1\GetItemsRequest;
						use Amazon\ProductAdvertisingAPI\v1\com\amazon\paapi5\v1\GetItemsResource;
						use Amazon\ProductAdvertisingAPI\v1\com\amazon\paapi5\v1\PartnerType;
						use Amazon\ProductAdvertisingAPI\v1\com\amazon\paapi5\v1\ProductAdvertisingAPIClientException;
						use Amazon\ProductAdvertisingAPI\v1\Configuration;


						require_once( __DIR__ . '/vendor/autoload.php');


						function parseResponse($items)
						{
						    $mappedResponse = [];
						    foreach ($items as $item) {
						        $mappedResponse[$item->getASIN()] = $item;
						    }
						    return $mappedResponse;
						}


						function getItems($itemId)
						{
						    $config = new Configuration();

						    /*
						     * Add your credentials
						     */
						    # Please add your access key here
						    $config->setAccessKey('AKIAJHHEXMXK337I4FSQ');
						    # Please add your secret key here
						    $config->setSecretKey('cEPSbaEzXX7XnPWJz0flLbwMqiAwW/5gpvwjNXqP');

						    # Please add your partner tag (store/tracking id) here
						    $partnerTag = 'xbit-20';

						    /*
						     * PAAPI host and region to which you want to send request
						     * For more details refer:
						     * https://webservices.amazon.com/paapi5/documentation/common-request-parameters.html#host-and-region
						     */
						    $config->setHost('webservices.amazon.com');
						    $config->setRegion('us-east-1');




						    # Choose item id(s)
						    $itemIds = [$itemId];

						    $apiInstance = new DefaultApi(
						        /*
						         * If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
						         * This is optional, `GuzzleHttp\Client` will be used as default.
						         */
						        new GuzzleHttp\Client(),
						        $config
						    );

						    $resources = [
						        GetItemsResource::ITEM_INFOTITLE,
						        GetItemsResource::OFFERSLISTINGSPRICE];

						    # Forming the request
						    $getItemsRequest = new GetItemsRequest();
						    $getItemsRequest->setItemIds($itemIds);
						    $getItemsRequest->setPartnerTag($partnerTag);
						    $getItemsRequest->setPartnerType(PartnerType::ASSOCIATES);
						    $getItemsRequest->setResources($resources);

						    # Validating request
						    $invalidPropertyList = $getItemsRequest->listInvalidProperties();
						    $length = count($invalidPropertyList);
						    if ($length > 0) {
						        echo "Error forming the request", PHP_EOL;
						        foreach ($invalidPropertyList as $invalidProperty) {
						            echo $invalidProperty, PHP_EOL;
						        }
						        return;
						    }

						    # Sending the request
						    try {
						        $getItemsResponse = $apiInstance->getItems($getItemsRequest);

						        $responseList = parseResponse($getItemsResponse->getItemsResult()->getItems());

						        $item = $responseList[$itemId];

						        $price = $item->getOffers()->getListings()[0]->getPrice()->getDisplayAmount();

						        $price = explode(" ", $price)[0];

						        return $price;

						    } catch (ApiException $exception) {
						        echo "Error calling PA-API 5.0!", PHP_EOL;
						        echo "HTTP Status Code: ", $exception->getCode(), PHP_EOL;
						        echo "Error Message: ", $exception->getMessage(), PHP_EOL;
						        if ($exception->getResponseObject() instanceof ProductAdvertisingAPIClientException) {
						            $errors = $exception->getResponseObject()->getErrors();
						            foreach ($errors as $error) {
						                echo "Error Type: ", $error->getCode(), PHP_EOL;
						                echo "Error Message: ", $error->getMessage(), PHP_EOL;
						            }
						        } else {
						            echo "Error response body: ", $exception->getResponseBody(), PHP_EOL;
						        }
						    } catch (Exception $exception) {
						        echo "Error Message: ", $exception->getMessage(), PHP_EOL;
						    }


						}

					?>

<?php
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

echo '<pre>';

$sql = "SELECT * FROM wp_posts WHERE post_type='product'";

$products = $conn->query($sql);

if ($products->num_rows > 0) {
  // output data of each row
  echo '<table cellspacing="2" border="1" cellpadding="5" width="100%">';
  echo '<thead>';
  echo '<tr><td>#</td><td>Product Name</td><td>Current price</td><td>Amazon price</td><td>Action</td>';
  echo '</thead>';
  $n = 1;
  while($row = $products->fetch_assoc()) {
  	$product_id = $row["ID"];
  	$sql = "SELECT meta_key FROM wp_postmeta WHERE CONVERT(`meta_key` USING utf8) LIKE 'where_to_buy%' AND post_id = $product_id AND meta_value='amazon.com' LIMIT 1";
  	$result = $conn->query($sql);
  	
  	if ($result->num_rows > 0) {
  		while($data = $result->fetch_assoc()) {
  			echo '<tr>';
  			echo '<td>' . $n . '</td>';
  			echo '<td>' . $row["post_title"] . '</td>';
  			$meta_key = $data['meta_key'];

  			$key_number = explode("_", $meta_key)[3];

  			$meta_key = 'where_to_buy_' . $key_number . '_amazon_id';

  			$sql = "SELECT meta_value FROM wp_postmeta WHERE meta_key = '" . $meta_key . "' AND post_id = " . $product_id;

  			$amazon_id = $conn->query($sql);

  			if ($amazon_id->num_rows > 0) {
  				while($amazon = $amazon_id->fetch_assoc()) {

  					$product_price = getItems($amazon["meta_value"]);

  					$meta_key = 'where_to_buy_' . $key_number . '_price';

  					$sql = "SELECT meta_value FROM wp_postmeta WHERE meta_key = '" . $meta_key . "' AND post_id = " . $product_id;

  					$current_price = $conn->query($sql);

  					if ($current_price->num_rows > 0) {
  						while($cprice = $current_price->fetch_assoc()) {
  							echo '<td>' . $cprice["meta_value"] . '</td>';
  							echo '<td>' . $product_price . '</td>';

		  					if ($product_price == $cprice["meta_value"]) {

		  						echo '<td>No update required</td>';
		  						
		  						
		  					} else {
		  						$sql = "UPDATE wp_postmeta SET meta_value='" . $product_price . "' WHERE meta_key = '" . $meta_key . "' AND post_id = " . $product_id;

					  			if (mysqli_query($conn, $sql)) {
									  echo '<td>Price updated</td>';
									} else {
									  echo "Error updating record: " . mysqli_error($conn);
									}
		  					}
  						}
  					}
	  			
  				}
  			}
  			echo '</tr>';
  			$n++;
  		}
  		
  	}
  	
  }
  echo '</table>';
} else {
  echo "0 results";
}


echo '</pre>';

$conn->close();

?>